(function(){
var C=window.FB_CONFIG||{};if(!window.supabase||!C.url||!C.key)return;
var sb=window.supabase.createClient(C.url,C.key),S={},F={};
var st=document.createElement('style');st.textContent='#ob{position:fixed;inset:0;z-index:10000;background:linear-gradient(160deg,#6c4cf1,#c04cf1);overflow:auto;display:flex;padding:16px;font-family:system-ui,sans-serif;color:#1a1d29;box-sizing:border-box}#ob *{box-sizing:border-box}#ob .bx{background:#fff;border-radius:26px;padding:22px 20px;width:100%;max-width:440px;margin:auto;box-shadow:0 20px 60px #0004}#ob h2{margin:8px 0 4px;font-size:23px}#ob p{color:#6b7280;margin:0 0 14px;line-height:1.4}#ob input[type=text],#ob input[type=email],#ob input[type=password],#ob input[type=date]{width:100%;padding:14px;margin:6px 0;border:1.5px solid #e5e7f0;border-radius:14px;font-size:16px;background:#fff;color:#1a1d29}#ob input:focus{outline:0;border-color:#6c4cf1}#ob .bt{width:100%;padding:15px;border:0;border-radius:14px;background:linear-gradient(135deg,#6c4cf1,#c04cf1);color:#fff;font-size:16px;font-weight:700;margin-top:12px}#ob .bt:disabled{opacity:.5}#ob .gh{background:none;color:#6c4cf1;border:0;padding:12px;width:100%;font-size:15px}#ob .dots{display:flex;gap:6px;justify-content:center}#ob .dots i{width:28px;height:5px;border-radius:3px;background:#e5e7f0}#ob .dots i.on{background:#6c4cf1}#ob .er{color:#e0364c;font-size:14px;min-height:20px;margin-top:4px}#ob .ok{font-size:13px;min-height:16px}#ob .chips{display:flex;gap:8px;margin-top:8px}#ob .chips label{flex:1;text-align:center;border:1.5px solid #e5e7f0;border-radius:14px;padding:13px 2px;cursor:pointer}#ob .chips input{display:none}#ob .chips label.sel{border-color:#6c4cf1;background:#f3f0ff;color:#6c4cf1;font-weight:700}#ob .cv{height:140px;border-radius:18px;background:#e9e5ff center/cover;position:relative;overflow:hidden}#ob .av{width:108px;height:108px;border-radius:50%;background:#d8d0ff center/cover;border:4px solid #fff;margin:-54px auto 0;position:relative;overflow:hidden;box-shadow:0 4px 14px #0003}#ob .pk{position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;cursor:pointer;font-size:0}#ob .cap{position:absolute;left:0;right:0;bottom:0;text-align:center;background:#0006;color:#fff;font-size:12px;padding:5px}#ob .av .cap{top:40%;bottom:auto;background:none;font-size:30px}#ob .meter{height:6px;border-radius:3px;background:#e5e7f0;overflow:hidden;margin:4px 0 8px}#ob .meter i{display:block;height:100%;width:0;transition:.3s}';document.head.appendChild(st);
function $(i){return document.getElementById(i)}
function ov(){var o=$('ob');if(!o){o=document.createElement('div');o.id='ob';document.body.appendChild(o)}return o}
function close(){var o=$('ob');if(o)o.remove()}
function esc(v){return String(v==null?'':v).replace(/"/g,'&quot;').replace(/</g,'&lt;')}
function dots(n,i){var s='';for(var k=0;k<n;k++)s+='<i class="'+(k<=i?'on':'')+'"></i>';return '<div class="dots">'+s+'</div>'}
function shell(h){ov().innerHTML='<div class="bx">'+h+'</div>'}
var RU=/^[A-Za-z0-9_]{3,20}$/,RE=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
async function taken(u){var r=await sb.from('profiles').select('id').ilike('username',u).maybeSingle();return !!(r&&r.data)}
function reg(i){
 var G=[['male','👨 Male'],['female','👩 Female'],['other','🙂 Other']].map(function(g){return '<label class="'+(S.gender===g[0]?'sel':'')+'"><input type="radio" name="g" value="'+g[0]+'"'+(S.gender===g[0]?' checked':'')+'>'+g[1]+'</label>'}).join('');
 var f=[['আপনার নাম কী?','চলুন আপনার Account তৈরি করি','<input type="text" id="a" placeholder="পূর্ণ নাম" value="'+esc(S.name)+'" autocomplete="name">'],
 ['Username ও Email','Username দিয়ে অন্যরা আপনাকে খুঁজে পাবে','<input type="text" id="a" placeholder="Username (a-z, 0-9, _)" value="'+esc(S.user)+'" autocapitalize="none" autocomplete="username"><div id="u" class="ok"></div><input type="email" id="b" placeholder="Email" value="'+esc(S.email)+'" autocomplete="email">'],
 ['নিরাপদ Password','কমপক্ষে ৮ অক্ষর; অক্ষর, সংখ্যা ও চিহ্ন মেশালে আরও নিরাপদ','<input type="password" id="a" placeholder="Password" autocomplete="new-password"><div class="meter"><i id="m"></i></div><input type="password" id="b" placeholder="আবার লিখুন" autocomplete="new-password">'],
 ['জন্ম তারিখ ও Gender','আপনার বয়স কমপক্ষে ১৩ বছর হতে হবে','<input type="date" id="a" value="'+esc(S.dob)+'"><div class="chips">'+G+'</div>']][i];
 shell(dots(4,i)+'<h2>'+f[0]+'</h2><p>'+f[1]+'</p>'+f[2]+'<div class="er" id="er"></div><button class="bt" id="nx">'+(i==3?'Account তৈরি করুন ✓':'পরের ধাপ →')+'</button><button class="gh" id="bk">'+(i?'← পেছনে':'বাতিল')+'</button>');
 var a=$('a'),b=$('b'),er=$('er');
 if(i==1)a.onblur=async function(){var v=a.value.trim(),u=$('u');if(!RU.test(v)){u.style.color='#e0364c';u.textContent=v?'৩-২০ অক্ষর: a-z, 0-9, _':'';return}var t=await taken(v);u.style.color=t?'#e0364c':'#16a34a';u.textContent=t?'✗ এই Username আছে':'✓ Username পাওয়া যাবে'};
 if(i==2)a.oninput=function(){var v=a.value,sc=(v.length>=8)+(/[A-Za-z]/.test(v)&&/\d/.test(v))+(/[A-Z]/.test(v))+(/[^A-Za-z0-9]/.test(v)),m=$('m');m.style.width=(sc*25)+'%';m.style.background=['#e0364c','#e0364c','#f59e0b','#22c55e','#16a34a'][sc]};
 if(i==3)Array.prototype.forEach.call(document.querySelectorAll('#ob .chips input'),function(r){r.onchange=function(){Array.prototype.forEach.call(document.querySelectorAll('#ob .chips label'),function(l){l.className=l.firstChild.checked?'sel':''})}});
 $('bk').onclick=function(){i?reg(i-1):close()};
 $('nx').onclick=async function(){var btn=this;er.textContent='';btn.disabled=true;
  try{
   if(i==0){if(a.value.trim().length<2)throw new Error('আপনার নাম লিখুন');S.name=a.value.trim();reg(1);return}
   if(i==1){var u=a.value.trim(),em=b.value.trim();if(!RU.test(u))throw new Error('Username ৩-২০ অক্ষর হতে হবে (a-z, 0-9, _)');if(!RE.test(em))throw new Error('সঠিক Email দিন');if(await taken(u))throw new Error('এই Username আগে থেকেই আছে');S.user=u;S.email=em;reg(2);return}
   if(i==2){if(a.value.length<8)throw new Error('Password কমপক্ষে ৮ অক্ষর হতে হবে');if(a.value!==b.value)throw new Error('দুই Password মেলেনি');S.pass=a.value;reg(3);return}
   var g=document.querySelector('#ob input[name=g]:checked');if(!a.value)throw new Error('জন্ম তারিখ দিন');if((Date.now()-new Date(a.value))/31557600000<13)throw new Error('বয়স কমপক্ষে ১৩ বছর হতে হবে');if(!g)throw new Error('Gender বাছাই করুন');
   S.dob=a.value;S.gender=g.value;
   var r=await sb.auth.signUp({email:S.email,password:S.pass,options:{data:{username:S.user,full_name:S.name,dob:S.dob,gender:S.gender}}});if(r.error)throw r.error;S.pass='';
   if(r.data&&r.data.session)photos(r.data.user.id);else{shell('<h2>✅ Account তৈরি হয়েছে</h2><p>আপনার Email-এ একটি লিংক পাঠানো হয়েছে। লিংকে চাপ দিয়ে Account নিশ্চিত করুন, তারপর Login করুন।</p><button class="bt" id="cl">ঠিক আছে</button>');$('cl').onclick=close}
  }catch(e){er.textContent=e.message||String(e);btn.disabled=false}};
}
async function up(uid,f){var M={jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif'},ext=(f.name.split('.').pop()||'').toLowerCase(),p=uid+'/'+Date.now()+'-'+f.name.replace(/[^\w.-]/g,'_'),r=await sb.storage.from('media').upload(p,f,{contentType:f.type||M[ext]||'image/jpeg'});if(r.error)throw r.error;return sb.storage.from('media').getPublicUrl(p).data.publicUrl}
function photos(uid){F={};
 shell(dots(4,3)+'<h2 style="text-align:center">Profile সাজান ✨</h2><p style="text-align:center">একবার Profile ও Cover ছবি দিন, পরে Settings থেকে বদলাতে পারবেন</p><div class="cv" id="cv"><span class="cap">📷 Cover ছবি বাছাই করুন</span><input class="pk" type="file" accept="image/*" id="fc"></div><div class="av" id="av"><span class="cap">👤</span><input class="pk" type="file" accept="image/*" id="fa"></div><div class="er" id="er" style="text-align:center"></div><button class="bt" id="sv">Save করে শুরু করুন</button><button class="gh" id="sk">পরে করব</button>');
 function pv(inp,box,key){inp.onchange=function(){var f=inp.files&&inp.files[0];if(!f)return;F[key]=f;box.style.backgroundImage='url('+URL.createObjectURL(f)+')';var c=box.querySelector('.cap');if(c)c.style.display='none'}}
 pv($('fc'),$('cv'),'c');pv($('fa'),$('av'),'a');
 function fin(){try{localStorage.setItem('fb_ob_'+uid,'1')}catch(e){}}
 $('sk').onclick=function(){fin();close()};
 $('sv').onclick=async function(){var btn=this,er=$('er');if(!F.a&&!F.c){fin();close();return}btn.disabled=true;er.style.color='#6b7280';er.textContent='⏳ আপলোড হচ্ছে...';
  try{var u={};if(F.c){u.cover_url=await up(uid,F.c);await sb.from('photo_history').insert({user_id:uid,kind:'cover',url:u.cover_url})}if(F.a){u.avatar_url=await up(uid,F.a);await sb.from('photo_history').insert({user_id:uid,kind:'avatar',url:u.avatar_url})}
   var r=await sb.from('profiles').update(u).eq('id',uid);if(r.error)throw r.error;fin();location.reload()}
  catch(e){er.style.color='#e0364c';er.textContent='Error: '+(e.message||e);btn.disabled=false}};
}
document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a');if(a&&a.closest('.auth')&&/নতুন Account|New account/.test(a.textContent)){e.preventDefault();e.stopPropagation();S={};reg(0)}},true);
async function check(){if($('ob'))return;try{var r=await sb.auth.getSession(),s=r.data&&r.data.session;if(!s)return;var uid=s.user.id;if(localStorage.getItem('fb_ob_'+uid))return;var p=await sb.from('profiles').select('avatar_url,cover_url').eq('id',uid).maybeSingle();if(p.data&&!p.data.avatar_url&&!p.data.cover_url)photos(uid);else if(p.data)localStorage.setItem('fb_ob_'+uid,'1')}catch(e){}}
setInterval(check,3000);check();
})();
