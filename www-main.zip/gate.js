(function(){
var C=window.FB_CONFIG||{};if(!window.supabase||!C.url||!C.key)return;
var sb=window.supabase.createClient(C.url,C.key),m=navigator.userAgent.match(/FBApp\/([\w.]+)\/(\d+)/),PKG=m&&m[1],VER=m?+m[2]:0;
function ov(h){var o=document.getElementById('fbgate');if(!o){o=document.createElement('div');o.id='fbgate';o.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;z-index:20000;background:linear-gradient(160deg,#6c4cf1,#c04cf1);color:#fff;display:flex;align-items:center;justify-content:center;text-align:center;padding:26px;font-family:system-ui,sans-serif';document.body.appendChild(o)}o.innerHTML=h}
function off(){var o=document.getElementById('fbgate');if(o)o.remove()}
function esc(v){return String(v||'').replace(/</g,'&lt;')}
async function isAdmin(){try{var r=await sb.auth.getSession(),s=r.data&&r.data.session;if(!s)return false;var a=await sb.from('admin_users').select('role').eq('user_id',s.user.id).maybeSingle();return !!(a&&a.data)}catch(e){return false}}
async function chk(){try{var r=await sb.from('settings').select('*'),S={};((r&&r.data)||[]).forEach(function(x){S[x.key]=x.value});
 if(S.update_required==='on'&&VER&&(!S.update_package||S.update_package===PKG)&&VER<(+S.update_version||0)){ov('<div style="max-width:360px"><div style="font-size:60px">⬇️</div><h2>নতুন আপডেট এসেছে</h2><p style="opacity:.9;line-height:1.5">'+esc(S.update_msg||'চালিয়ে যেতে অ্যাপ আপডেট করুন।')+'</p><button id="fbup" style="margin-top:14px;padding:15px 28px;border:0;border-radius:16px;background:#fff;color:#6c4cf1;font-size:17px;font-weight:700">⬇ আপডেট ডাউনলোড করুন</button></div>');document.getElementById('fbup').onclick=function(){if(S.update_url)location.href=S.update_url};return}
 if(S.maintenance_mode==='on'&&!(await isAdmin())){ov('<div style="max-width:360px"><div style="font-size:60px">🛠️</div><h2>রক্ষণাবেক্ষণ চলছে</h2><p style="opacity:.9;line-height:1.5">'+esc(S.maintenance_msg||'কিছুক্ষণ পর আবার চেষ্টা করুন।')+'</p></div>');return}
 off()}catch(e){}}
chk();setInterval(chk,45000);document.addEventListener('visibilitychange',function(){if(!document.hidden)chk()});
})();
