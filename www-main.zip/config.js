window.FB_CONFIG = {
  url: "https://vkkwqczbwpklrlddrzfj.supabase.co",
  key: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZra3dxY3pid3BrbHJsZGRyemZqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI0ODQ0MDEsImV4cCI6MjEwODA2MDQwMX0.uqNTvjEDIC90uGw5mf4Pi13tdHdSN3TLZE6Xg-Gota0",
  site: "https://friendsbook.site.je"
};
