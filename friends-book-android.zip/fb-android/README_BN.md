# Friends Book — Android App প্রজেক্ট

এই App আপনার ওয়েবসাইট (https://friendsbook.site.je) Android WebView-এ চালায়। তাই ওয়েবসাইটের **সব ফিচার** (Post, Story, Reaction, Messenger Chat, Audio/Video Call, Friend, Monetization, Admin Panel ইত্যাদি) App-এও আছে। ওয়েবসাইট আপডেট করলে App নিজে থেকে আপডেট হয়, নতুন APK বানাতে হয় না।

## ZIP-এর ভেতরে
- `app/` + `build.gradle` + `settings.gradle` : Android Studio/Gradle প্রজেক্ট
- `.github/workflows/build.yml` (কপি: `GITHUB_BUILD_WORKFLOW.yml.txt`) : GitHub-এ APK বানানোর স্ক্রিপ্ট
- `website/` : ওয়েবসাইটের ফাইল (htdocs-এ যা আপলোড করেছেন)
- `database/` : Supabase SQL (schema.sql → schema7.sql, এই ক্রমে)

## APK বানানোর ২টি উপায়
### উপায় ১ — শুধু মোবাইল দিয়ে (GitHub Actions, সবচেয়ে সহজ)
1. github.com-এ বিনামূল্যে Account খুলে নতুন Repository বানান।
2. এই ZIP-এর `app`, `build.gradle`, `settings.gradle`, `gradle.properties` আপলোড করুন।
3. Repository-তে `.github/workflows/build.yml` নামে ফাইল বানিয়ে `GITHUB_BUILD_WORKFLOW.yml.txt`-এর লেখা paste করুন।
4. **Actions** ট্যাব → "Build APK" → **Run workflow**। ৩-৫ মিনিট পর "FriendsBook-APK" ডাউনলোড করুন (ভেতরে app-debug.apk)।
5. ফোনে APK খুলে ইনস্টল করুন ("Unknown sources" অনুমতি দিতে হতে পারে)।

### উপায় ২ — মোবাইল Android IDE দিয়ে
প্রজেক্ট ফোল্ডার খুলে **Build → APK** চালান। (Gradle প্রজেক্ট সমর্থন করে এমন IDE লাগবে; Android Gradle Plugin 8.2.2, JDK 17, compileSdk 34।)

## ঠিকানা বদলাতে
`app/src/main/java/com/friendsbook/app/MainActivity.java`-এর শুরুতে `HOME` ও `HOST` বদলান। ঠিকানা অবশ্যই HTTPS হতে হবে।

## Play Store-এ দিতে চাইলে
Debug APK শুধু নিজের ব্যবহারের জন্য। Play Store-এর জন্য নিজের Keystore দিয়ে সাইন করা Release (AAB) বানাতে হবে, আর Privacy Policy লাগবে।

## App যা সমর্থন করে
ছবি/Video/গান আপলোড (একাধিক ছবি সহ), Camera ও Microphone (Audio/Video Call), পূর্ণ-পর্দা Video, Back বোতাম, ইন্টারনেট না থাকলে "আবার চেষ্টা করুন" পাতা।
