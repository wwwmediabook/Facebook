package com.friendsbook.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    // আপনার ওয়েবসাইটের ঠিকানা বদলাতে হলে শুধু এই দুই লাইন বদলান (HTTPS হতে হবে)
    static final String HOME = "https://friendsbook.site.je/";
    static final String HOST = "friendsbook.site.je";

    WebView web;
    FrameLayout root;
    ValueCallback<Uri[]> fileCb;
    PermissionRequest pendingReq;
    View customView;
    WebChromeClient.CustomViewCallback customCb;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (Build.VERSION.SDK_INT >= 21) getWindow().setStatusBarColor(Color.parseColor("#6c4cf1"));
        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " FriendsBookApp/1.0");
        CookieManager.getInstance().setAcceptCookie(true);

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost()) || "file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) v.loadUrl("file:///android_asset/offline.html");
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(new Runnable() { public void run() { handlePerm(req); } });
            }
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 200); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = v; customCb = cb;
                web.setVisibility(View.GONE);
                root.addView(v);
            }
            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                web.setVisibility(View.VISIBLE);
                if (customCb != null) customCb.onCustomViewHidden();
            }
        });

        if (saved != null) web.restoreState(saved); else web.loadUrl(HOME);
    }

    void handlePerm(PermissionRequest req) {
        List<String> missing = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 23) {
            for (String r : req.getResources()) {
                String p = null;
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) p = Manifest.permission.CAMERA;
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) p = Manifest.permission.RECORD_AUDIO;
                if (p != null && checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
            }
        }
        if (missing.isEmpty()) { req.grant(req.getResources()); }
        else { pendingReq = req; requestPermissions(missing.toArray(new String[0]), 100); }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == 100 && pendingReq != null) {
            boolean ok = res.length > 0;
            for (int x : res) if (x != PackageManager.PERMISSION_GRANTED) ok = false;
            if (ok) pendingReq.grant(pendingReq.getResources()); else pendingReq.deny();
            pendingReq = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 200 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { web.getWebChromeClient().onHideCustomView(); }
        else if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }
    @Override protected void onPause() { super.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
