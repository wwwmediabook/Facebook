-- schema.sql, schema2.sql এর পর run করুন
alter table posts add column media_type text check (media_type in ('image','video')), add column shared_post_id uuid references posts on delete set null;
create index on posts(media_type,created_at desc);
alter table profiles add column cover_url text;
alter table profiles drop constraint profiles_status_check, add constraint profiles_status_check check (status in ('normal','suspended','banned','deactivated'));
create table user_sessions(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade, device_id text not null,
 browser text, device_type text, login_at timestamptz default now(), last_active timestamptz default now(), unique(user_id,device_id));
create table calls(id uuid primary key default gen_random_uuid(), caller_id uuid not null references profiles on delete cascade, callee_id uuid not null references profiles on delete cascade,
 type text not null check (type in ('audio','video')), status text not null default 'ringing' check (status in ('ringing','accepted','rejected','ended','missed')), created_at timestamptz default now());
alter table user_sessions enable row level security; alter table calls enable row level security;
create policy us_all on user_sessions for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy ca_sel on calls for select using (auth.uid() in (caller_id,callee_id));
create policy ca_ins on calls for insert with check (caller_id=auth.uid() and not exists(select 1 from blocks b where (b.blocker_id=callee_id and b.blocked_id=caller_id) or (b.blocker_id=caller_id and b.blocked_id=callee_id)));
create policy ca_upd on calls for update using (auth.uid() in (caller_id,callee_id));
create function deactivate_my_account() returns void language sql security definer set search_path=public as $$ update profiles set status='deactivated' where id=auth.uid() $$;
create function delete_my_account() returns void language sql security definer set search_path=public,auth as $$ delete from auth.users where id=auth.uid() $$;
alter publication supabase_realtime add table calls;
insert into storage.buckets(id,name,public,file_size_limit) values('media','media',true,52428800) on conflict (id) do nothing;
create policy media_read on storage.objects for select using (bucket_id='media');
create policy media_ins on storage.objects for insert to authenticated with check (bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy media_del on storage.objects for delete to authenticated using (bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text);
