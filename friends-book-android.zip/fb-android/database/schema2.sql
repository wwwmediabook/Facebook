-- schema.sql এর পরে run করুন
create table saved_posts(user_id uuid references profiles on delete cascade, post_id uuid references posts on delete cascade, primary key(user_id,post_id));
create table blocks(blocker_id uuid references profiles on delete cascade, blocked_id uuid references profiles on delete cascade, primary key(blocker_id,blocked_id));
create table stories(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade, content text, media_url text,
 expires_at timestamptz not null default now()+interval '24 hours', created_at timestamptz default now());
create table reports(id uuid primary key default gen_random_uuid(), reporter_id uuid references profiles on delete set null,
 target_type text not null check (target_type in ('user','post','comment','story','message')), target_id uuid not null, reason text not null,
 status text default 'open' check (status in ('open','resolved')), created_at timestamptz default now());
create table messages(id uuid primary key default gen_random_uuid(), sender_id uuid not null references profiles on delete cascade,
 receiver_id uuid not null references profiles on delete cascade, body text not null check (length(body) between 1 and 4000), seen boolean default false, created_at timestamptz default now());
create index on messages(sender_id,receiver_id,created_at); create index on messages(receiver_id,seen);
create table notifications(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade,
 actor_id uuid references profiles on delete cascade, type text not null, ref_id uuid, read boolean default false, created_at timestamptz default now());
create index on notifications(user_id,read,created_at desc);
create table advertisements(id uuid primary key default gen_random_uuid(), title text not null, description text, image_url text, target_url text,
 type text default 'feed' check (type in ('banner','feed','video','sponsored','custom')), placement text default 'home_feed',
 status text default 'active' check (status in ('active','inactive')), frequency int default 4 check (frequency>=2),
 start_date timestamptz, end_date timestamptz, created_by uuid references profiles);

alter table saved_posts enable row level security; alter table blocks enable row level security; alter table stories enable row level security;
alter table reports enable row level security; alter table messages enable row level security; alter table notifications enable row level security; alter table advertisements enable row level security;
create policy sp_all on saved_posts for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy bl_all on blocks for all using (blocker_id=auth.uid()) with check (blocker_id=auth.uid());
create policy st_sel on stories for select using ((expires_at>now() and not exists(select 1 from blocks b where b.blocker_id=stories.user_id and b.blocked_id=auth.uid())) or user_id=auth.uid() or is_staff());
create policy st_ins on stories for insert with check (user_id=auth.uid());
create policy st_del on stories for delete using (user_id=auth.uid() or is_staff());
create policy rp_ins on reports for insert with check (reporter_id=auth.uid());
create policy rp_sel on reports for select using (is_staff());
create policy rp_upd on reports for update using (is_staff());
create policy ms_sel on messages for select using (sender_id=auth.uid() or receiver_id=auth.uid());
create policy ms_ins on messages for insert with check (sender_id=auth.uid() and not exists(select 1 from blocks b where (b.blocker_id=receiver_id and b.blocked_id=sender_id) or (b.blocker_id=sender_id and b.blocked_id=receiver_id)));
create policy ms_upd on messages for update using (receiver_id=auth.uid());
create policy ms_del on messages for delete using (sender_id=auth.uid());
create policy nt_sel on notifications for select using (user_id=auth.uid());
create policy nt_upd on notifications for update using (user_id=auth.uid());
create policy nt_del on notifications for delete using (user_id=auth.uid());
create policy ad_sel on advertisements for select using (status='active' or is_staff());
create policy ad_ins on advertisements for insert with check (is_staff());
create policy ad_upd on advertisements for update using (is_staff());
create policy ad_del on advertisements for delete using (is_staff());

create function notify() returns trigger language plpgsql security definer set search_path=public as $$
declare owner uuid; begin
 if TG_TABLE_NAME='likes' then select user_id into owner from posts where id=new.post_id; if owner<>new.user_id then insert into notifications(user_id,actor_id,type,ref_id) values(owner,new.user_id,'like',new.post_id); end if;
 elsif TG_TABLE_NAME='comments' then select user_id into owner from posts where id=new.post_id; if owner<>new.user_id then insert into notifications(user_id,actor_id,type,ref_id) values(owner,new.user_id,'comment',new.post_id); end if;
 elsif TG_TABLE_NAME='follows' then insert into notifications(user_id,actor_id,type) values(new.following_id,new.follower_id,'follow');
 elsif TG_TABLE_NAME='messages' then insert into notifications(user_id,actor_id,type,ref_id) values(new.receiver_id,new.sender_id,'message',new.id);
 end if; return new; end $$;
create trigger n_like after insert on likes for each row execute function notify();
create trigger n_cm after insert on comments for each row execute function notify();
create trigger n_fo after insert on follows for each row execute function notify();
create trigger n_ms after insert on messages for each row execute function notify();
alter publication supabase_realtime add table messages, notifications, stories;
