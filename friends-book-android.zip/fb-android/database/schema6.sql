-- schema5.sql এর পর run করুন
alter table stories add column media_type text check (media_type in ('image','video')), add column audio_url text;
