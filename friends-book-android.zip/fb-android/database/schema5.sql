-- schema4.sql এর পর run করুন
alter table advertisements add column code text;
alter table posts add column audio_url text;
alter table monetization add column last_tick timestamptz;
insert into settings values('earn_amount','1'),('earn_minutes','10'),('video_ad_seconds','5'),('video_ad_text','') on conflict do nothing;
create function earn_tick() returns void language plpgsql security definer set search_path=public as $$
declare a numeric; m numeric; begin
 select coalesce(nullif(value,'')::numeric,0) into a from settings where key='earn_amount';
 select coalesce(nullif(value,'')::numeric,0) into m from settings where key='earn_minutes';
 if m<=0 then return; end if;
 update monetization set balance=balance+round(a/m,4), last_tick=now() where user_id=auth.uid() and status='approved' and (last_tick is null or now()-last_tick>=interval '50 seconds'); end $$;
create table highlights(user_id uuid references profiles on delete cascade, post_id uuid references posts on delete cascade, primary key(user_id,post_id));
create table photo_history(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade, kind text not null check (kind in ('avatar','cover')), url text not null, created_at timestamptz default now());
create table verification_requests(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade, form jsonb not null,
 status text not null default 'pending' check (status in ('pending','approved','rejected')), admin_reply text, created_at timestamptz default now());
alter table highlights enable row level security; alter table photo_history enable row level security; alter table verification_requests enable row level security;
create policy hl_sel on highlights for select using (true);
create policy hl_ins on highlights for insert with check (user_id=auth.uid());
create policy hl_del on highlights for delete using (user_id=auth.uid());
create policy ph_all on photo_history for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy vr_sel on verification_requests for select using (user_id=auth.uid() or is_staff());
create policy vr_ins on verification_requests for insert with check (user_id=auth.uid() and status='pending');
create function admin_verify(rid uuid, ok boolean, reply text) returns void language plpgsql security definer set search_path=public as $$
declare u uuid; begin if not is_staff() then raise exception 'denied'; end if;
 update verification_requests set status=case when ok then 'approved' else 'rejected' end, admin_reply=reply where id=rid returning user_id into u;
 if ok then update profiles set verified=true where id=u; end if;
 insert into notifications(user_id,type,ref_id) values(u,'verify',rid); end $$;
