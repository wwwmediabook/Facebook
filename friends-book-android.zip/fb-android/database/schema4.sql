-- schema.sql, schema2.sql, schema3.sql এর পর এটি run করুন
create function my_verified() returns boolean language sql security definer stable set search_path=public as $$ select verified from profiles where id=auth.uid() $$;
create function my_status() returns text language sql security definer stable set search_path=public as $$ select status from profiles where id=auth.uid() $$;
drop policy p_upd on profiles;
create policy p_upd on profiles for update using (id=auth.uid() or is_staff())
 with check (is_staff() or (id=auth.uid() and verified=my_verified() and status=my_status()));
alter table profiles add column pro_mode boolean not null default false, add column is_private boolean not null default false;
alter table likes add column reaction text not null default 'like';
create policy likes_upd on likes for update using (user_id=auth.uid()) with check (user_id=auth.uid());
create function delete_post(pid uuid) returns void language plpgsql security definer set search_path=public as $$
begin delete from posts where id=pid and (user_id=auth.uid() or is_staff()); if not found then raise exception 'Delete করার অনুমতি নেই'; end if; end $$;
create table friend_requests(id uuid primary key default gen_random_uuid(), sender_id uuid not null references profiles on delete cascade,
 receiver_id uuid not null references profiles on delete cascade, status text not null default 'pending' check (status in ('pending','accepted')), created_at timestamptz default now(), check (sender_id<>receiver_id));
create unique index on friend_requests (least(sender_id,receiver_id),greatest(sender_id,receiver_id));
alter table friend_requests enable row level security;
create policy fr_sel on friend_requests for select using (auth.uid() in (sender_id,receiver_id));
create policy fr_ins on friend_requests for insert with check (sender_id=auth.uid() and status='pending');
create policy fr_upd on friend_requests for update using (receiver_id=auth.uid()) with check (receiver_id=auth.uid());
create policy fr_del on friend_requests for delete using (auth.uid() in (sender_id,receiver_id));
create table settings(key text primary key, value text);
alter table settings enable row level security;
create policy se_sel on settings for select using (true);
create policy se_all on settings for all using (is_staff()) with check (is_staff());
insert into settings values('withdraw_limit','500'),('video_ad_link','');
create table monetization(user_id uuid primary key references profiles on delete cascade, status text not null default 'invited' check (status in ('invited','requested','approved','rejected')),
 form jsonb, balance numeric not null default 0 check (balance>=0), created_at timestamptz default now());
create table withdrawals(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade, amount numeric not null, method text not null check (method in ('bkash','nagad')),
 account text not null, status text not null default 'pending' check (status in ('pending','paid','rejected')), created_at timestamptz default now());
alter table monetization enable row level security; alter table withdrawals enable row level security;
create policy mo_sel on monetization for select using (user_id=auth.uid() or is_staff());
create policy mo_all on monetization for all using (is_staff()) with check (is_staff());
create policy wd_sel on withdrawals for select using (user_id=auth.uid() or is_staff());
create function submit_monetization(f jsonb) returns void language sql security definer set search_path=public as $$
 update monetization set form=f,status='requested' where user_id=auth.uid() and status in ('invited','rejected') $$;
create function request_withdraw(amt numeric,mth text,acc text) returns void language plpgsql security definer set search_path=public as $$
declare lim numeric; b numeric; begin
 select balance into b from monetization where user_id=auth.uid() and status='approved' for update;
 select coalesce(nullif(value,'')::numeric,0) into lim from settings where key='withdraw_limit';
 if b is null then raise exception 'Monetization approved নয়'; end if;
 if amt<=0 or amt>b or b<coalesce(lim,0) then raise exception 'Limit পূরণ হয়নি বা amount ভুল'; end if;
 update monetization set balance=balance-amt where user_id=auth.uid();
 insert into withdrawals(user_id,amount,method,account) values(auth.uid(),amt,mth,acc); end $$;
create function admin_withdraw(wid uuid,s text) returns void language plpgsql security definer set search_path=public as $$
begin if not is_staff() then raise exception 'denied'; end if;
 if s='rejected' then update monetization set balance=balance+(select amount from withdrawals where id=wid and status='pending') where user_id=(select user_id from withdrawals where id=wid and status='pending'); end if;
 update withdrawals set status=s where id=wid and status='pending'; end $$;
