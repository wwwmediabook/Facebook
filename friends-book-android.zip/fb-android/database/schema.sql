-- Friends Book core schema (Supabase SQL Editor-এ run করুন)
create table profiles(id uuid primary key references auth.users on delete cascade,
 username text unique not null, full_name text, avatar_url text, bio text,
 status text not null default 'normal' check (status in ('normal','suspended','banned')),
 verified boolean not null default false, created_at timestamptz default now());
create table admin_users(user_id uuid primary key references profiles on delete cascade,
 role text not null check (role in ('super_admin','admin','moderator')));
create table posts(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade,
 caption text, media_url text, privacy text default 'public' check (privacy in ('public','followers','private')),
 status text default 'published' check (status in ('published','hidden','deleted')), created_at timestamptz default now());
create table likes(post_id uuid references posts on delete cascade, user_id uuid references profiles on delete cascade, primary key(post_id,user_id));
create table comments(id uuid primary key default gen_random_uuid(), post_id uuid not null references posts on delete cascade,
 user_id uuid not null references profiles on delete cascade, parent_id uuid references comments on delete cascade,
 body text not null check (length(body) between 1 and 2000), created_at timestamptz default now());
create table follows(follower_id uuid references profiles on delete cascade, following_id uuid references profiles on delete cascade,
 primary key(follower_id,following_id), check (follower_id<>following_id));
create index on posts(created_at desc); create index on comments(post_id); create index on follows(following_id);

create function is_staff() returns boolean language sql security definer stable set search_path=public as
$$ select exists(select 1 from admin_users where user_id=auth.uid()) $$;
create function email_by_username(u text) returns text language sql security definer stable set search_path=public,auth as
$$ select a.email from auth.users a join profiles p on p.id=a.id where lower(p.username)=lower(u) $$;
create function handle_new_user() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into profiles(id,username,full_name) values(new.id, coalesce(new.raw_user_meta_data->>'username','user'||substr(new.id::text,1,8)), new.raw_user_meta_data->>'full_name'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

alter table profiles enable row level security; alter table admin_users enable row level security;
alter table posts enable row level security; alter table likes enable row level security;
alter table comments enable row level security; alter table follows enable row level security;

create policy p_sel on profiles for select using (true);
create policy p_upd on profiles for update using (id=auth.uid() or is_staff())
 with check (is_staff() or (id=auth.uid() and verified=(select verified from profiles where id=auth.uid()) and status=(select status from profiles where id=auth.uid())));
create policy p_del on profiles for delete using (is_staff());
create policy a_sel on admin_users for select using (user_id=auth.uid() or is_staff());
create policy posts_sel on posts for select using (is_staff() or (status='published' and (privacy='public' or user_id=auth.uid()
 or (privacy='followers' and exists(select 1 from follows f where f.follower_id=auth.uid() and f.following_id=posts.user_id)))));
create policy posts_ins on posts for insert with check (user_id=auth.uid() and exists(select 1 from profiles where id=auth.uid() and status='normal'));
create policy posts_upd on posts for update using (user_id=auth.uid() or is_staff());
create policy posts_del on posts for delete using (user_id=auth.uid() or is_staff());
create policy likes_sel on likes for select using (true);
create policy likes_ins on likes for insert with check (user_id=auth.uid());
create policy likes_del on likes for delete using (user_id=auth.uid());
create policy cm_sel on comments for select using (true);
create policy cm_ins on comments for insert with check (user_id=auth.uid());
create policy cm_del on comments for delete using (user_id=auth.uid() or is_staff());
create policy fo_sel on follows for select using (true);
create policy fo_ins on follows for insert with check (follower_id=auth.uid());
create policy fo_del on follows for delete using (follower_id=auth.uid());

alter publication supabase_realtime add table posts, likes, comments;
-- Admin বানাতে: insert into admin_users values ('<your-user-uuid>','super_admin');
