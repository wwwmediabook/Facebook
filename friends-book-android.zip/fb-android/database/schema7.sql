-- schema6.sql এর পর run করুন
alter table posts add column media_urls text[];
